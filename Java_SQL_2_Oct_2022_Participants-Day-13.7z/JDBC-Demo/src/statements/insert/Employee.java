package statements.insert;

public class Employee {

	int id;
	String name;
	String address;
	
}
