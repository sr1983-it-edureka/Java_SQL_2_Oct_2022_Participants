
public class ForLoop {

	public static void main(String[] args) {
	
		for (int counter = 10; counter <=4; counter ++) {

			System.out.println("I will do exercise regularly...");

		}
				
	}
}
