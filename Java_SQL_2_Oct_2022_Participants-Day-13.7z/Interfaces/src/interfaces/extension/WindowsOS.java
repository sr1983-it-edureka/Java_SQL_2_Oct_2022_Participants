package interfaces.extension;

public interface WindowsOS extends OS{

	void createMicrosoftAccount();
	
	// F2
	
	// F3
}
