package interfaces;

public interface Runnable {
	void run();
}
