package classes;
import interfaces.Flyable;
import interfaces.Vehicle;

public class Helicopter 
	implements Vehicle, Flyable{

	@Override
	public void start() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		
	}

}
