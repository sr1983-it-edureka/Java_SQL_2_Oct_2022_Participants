
public class StaticPolymorphism {

	public static void main(String[] args) {
		
		// Compile time Polymorphism / Static 
		
		// add (element)
		// forms / expression
			// add 2 integers
			// add 3 integers
			// add 2 floats
			// add 3 floats
		//
	}
}
