package network;

public class IntranetUtils {

	void connectToIntranet() {
		System.out.println("Connected to Intranet");
	}
	
	void disconnectFromIntranet() {
		System.out.println("Disconnected from Intranet..");
	}
}
