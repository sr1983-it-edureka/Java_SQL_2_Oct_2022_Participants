package network;

public class InternetUtils {

	void connectToInternet() {
		
		System.out.println("Connect to Internet");
	}

	void disconnectFromInternet() {
		System.out.println("Disconnect from Internet");
		
	}
}
