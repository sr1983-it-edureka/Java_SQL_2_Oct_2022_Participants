import java.util.ArrayList;

class CollectionSamples {

	static ArrayList<String> colorsList(){
		
		ArrayList<String> listOfColors = new ArrayList();
		
		listOfColors.add("Blue");
		listOfColors.add("Pink");
		listOfColors.add("Orange");
//		listOfColors.add(10);
		
		return listOfColors;
	}
	
	// 

	static ArrayList<Integer> randomNumbers(){
		
		ArrayList<Integer> randomNumbers = new ArrayList<>();
		
		randomNumbers.add(344933);
		randomNumbers.add(32032);
		randomNumbers.add(232);
		randomNumbers.add(8232);
		randomNumbers.add(9232);
		randomNumbers.add(743232);
		
		
		return randomNumbers;
	}
}
