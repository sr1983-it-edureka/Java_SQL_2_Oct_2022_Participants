
public class IFElseDemo {

	public static void main(String[] args) {
		
//		int a = 10;
		
		// 1 - 7
		// 1 - Monday, 2 - Tuesday ... 7-Sunday
		
		int dayOfWeek = 3;
		
		if (dayOfWeek == 6 || dayOfWeek == 7) {
			System.out.println("Weekend !....");
		}else {
			System.out.println("Weekday ....");
		}
		
	}
	
}
