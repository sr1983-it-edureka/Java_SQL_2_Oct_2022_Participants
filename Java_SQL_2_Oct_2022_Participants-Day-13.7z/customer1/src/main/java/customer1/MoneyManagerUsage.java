package customer1;

import com.cognizant.finance.MoneyManager;

public class MoneyManagerUsage {

	public static void main(String[] args) {
		
		MoneyManager manager = new MoneyManager();
		
		manager.manage();
	}
}
