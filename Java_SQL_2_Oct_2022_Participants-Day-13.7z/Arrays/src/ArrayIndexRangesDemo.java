
public class ArrayIndexRangesDemo {

	public static void main(String[] args) {
		
		// Length - 4
		// Index [0 - 3]
		char [] appraisalRatings = {'A', 'B', 'A', 'C'};
		
		char tenthElement = appraisalRatings[-1];
		System.out.println("Tenthh Element -> " + tenthElement);
	}
}
