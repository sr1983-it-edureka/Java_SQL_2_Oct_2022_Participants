package datatypes.decimals;


public class FloatDataType {

	public static void main(String[] args) {
		
		// 4 bytes
		// calculate range
		
		float f1 = 123.456F;
	}
}
