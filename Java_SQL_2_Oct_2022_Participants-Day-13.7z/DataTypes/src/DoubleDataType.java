
public class DoubleDataType {

	public static void main(String[] args) {
		
		double d1 = 3.14D;
		// 8 bytes
	}
}
