/**
 * 
 */
/**
 * @author labuser
 *
 */
module JavaProject1 {
}