package com.tcs.product2;

public class Result {

}
