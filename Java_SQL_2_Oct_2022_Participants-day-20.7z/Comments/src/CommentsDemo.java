
/**
		 * This is an example for multi-line comments.
		 * As we can we are able to write a paragraph 
		 * of infrmation here.
		 */
public class CommentsDemo {

	public static void main(String[] args) {
		
		
		/*
		 * This is an example for multi-line comments.
		 * As we can we are able to write a paragraph 
		 * of infrmation here.
		 */
	}
	
	// The working of the algorithm. This one has seven steps
	/**
	 * The working of the algorithm. This one has seven steps
	 */
	static void myAlgorithm() {
		
		///
		//
		///
		///
		//
		
	}
}
