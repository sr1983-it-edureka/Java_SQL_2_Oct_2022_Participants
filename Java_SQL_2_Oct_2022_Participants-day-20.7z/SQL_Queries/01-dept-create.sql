create table department (
	deptno integer,
    dname varchar(20),
    loc varchar(20),
    primary key (deptno)
);