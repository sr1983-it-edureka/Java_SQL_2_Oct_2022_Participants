select * from employee;

select * from employee where ename = 'JENNY';

select * from employee where ename like 'J%';

select * from employee where ename like '%Y';

select * from employee where ename like 'H%Y';

select * from employee where mgr like '1%';


