create table player_india as
	select * from player where country = 'India';
    
create table player_SA as
	select * from player where country = 'South Africa';
    
    