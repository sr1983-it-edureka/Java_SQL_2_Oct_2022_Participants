desc player;

create table player2 like player;
desc player2;

select * from player2;

