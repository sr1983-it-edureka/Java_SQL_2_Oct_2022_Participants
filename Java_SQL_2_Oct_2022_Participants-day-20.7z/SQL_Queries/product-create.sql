create table product (
	pid integer,
    pname varchar(10),
    category varchar(10)
);

desc product;
