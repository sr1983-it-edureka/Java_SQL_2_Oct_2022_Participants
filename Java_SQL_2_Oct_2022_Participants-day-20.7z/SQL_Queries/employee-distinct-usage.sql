
select * from employee;

select job from employee;

select count( job ) from employee;

select distinct JOB from employee;

select count(distinct JOB) from employee;

