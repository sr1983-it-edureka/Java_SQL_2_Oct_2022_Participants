select * from player_india;
desc player_india;

truncate table player_india;

drop table player_india;
