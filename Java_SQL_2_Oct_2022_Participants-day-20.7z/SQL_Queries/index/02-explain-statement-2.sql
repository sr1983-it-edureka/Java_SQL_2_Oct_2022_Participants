explain SELECT * FROM player where country = 'South Africa';


--
-- '1', 'SIMPLE', 'player', NULL, 'ref', 'player_country', --'player_country', '1023', 'const', '42', '100.00', NULL
