select * from player ;

select * from player limit 20;


select * from player limit 20 offset 20;

select * from player limit 20 offset 60;


select * from player limit 45 offset 120;

select * from player limit 45 offset 240;







