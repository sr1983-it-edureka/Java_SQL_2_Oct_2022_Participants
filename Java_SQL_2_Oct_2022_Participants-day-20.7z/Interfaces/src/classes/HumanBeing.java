package classes;
import interfaces.Playable;
import interfaces.Runnable;
import interfaces.Singable;

public class HumanBeing implements Runnable, Singable, Playable{

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
