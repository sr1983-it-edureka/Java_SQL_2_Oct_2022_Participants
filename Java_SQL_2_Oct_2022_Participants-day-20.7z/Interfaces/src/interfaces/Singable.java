package interfaces;

public interface Singable {
	
	void sing();
}
