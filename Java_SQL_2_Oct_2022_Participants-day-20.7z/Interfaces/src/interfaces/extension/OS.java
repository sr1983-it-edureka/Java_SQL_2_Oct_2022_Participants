package interfaces.extension;

public interface OS {

	void installedOnMachine();
	
	void uninstalledFromMachine();
}
