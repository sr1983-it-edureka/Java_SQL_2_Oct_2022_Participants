package demo3;

public class PenDriveImpl
	implements PenDrive{

	@Override
	public String readData() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void writeData(String data) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void plugin() {
		// TODO Auto-generated method stub
		
	}

}
