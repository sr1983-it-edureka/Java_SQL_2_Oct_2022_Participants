package com.cognizant.calculator;

public class TrignometricFunctionUtils {

}
