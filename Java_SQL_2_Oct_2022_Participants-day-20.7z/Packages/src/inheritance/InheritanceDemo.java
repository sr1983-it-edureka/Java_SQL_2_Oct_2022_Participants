package inheritance;

public class InheritanceDemo {

}
