package unary;

public class LogicalOperators_NOT {

	public static void main(String[] args) {
		
		boolean b1 = false;
		
		// Logical NOT
		// Unary Operator
		boolean b2 = !b1;
		
		System.out.println(b1);
		System.out.println(b2);
	}
}
