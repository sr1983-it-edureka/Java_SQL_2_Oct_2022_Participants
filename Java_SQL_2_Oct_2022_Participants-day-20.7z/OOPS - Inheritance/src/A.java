
public class A {

	void function1() {
		
	}
}


class B {
	
	void function1 () {
		
	}
	
}

//class C extends A, B{

class C extends A{

}

