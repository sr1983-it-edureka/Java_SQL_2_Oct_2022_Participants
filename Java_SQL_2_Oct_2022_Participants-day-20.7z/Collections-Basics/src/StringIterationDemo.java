
public class StringIterationDemo {

	public static void main(String[] args) {
		
		String str = "Hello";
		
//		for (Character c : str) {
//			System.out.println(c);
//		}
	}
}
