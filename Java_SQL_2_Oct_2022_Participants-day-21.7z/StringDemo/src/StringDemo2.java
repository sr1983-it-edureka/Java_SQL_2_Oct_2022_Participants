
public class StringDemo2 {

	public static void main(String[] args) {
		
		
		String str = "Today I started learning with OOPs"
			+ ". Then i jumped into the dicussion of String Builder."
			+ "I am not sure when OOPS concept will be resumed..";
		
		System.out.println(str);
		
		String color = "RED";
		
		color = "BLUE";
		
		color = "BLACK";
		
	}
}
