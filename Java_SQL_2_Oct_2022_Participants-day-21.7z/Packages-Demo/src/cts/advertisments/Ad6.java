package cts.advertisments;

public class Ad6 {

}
