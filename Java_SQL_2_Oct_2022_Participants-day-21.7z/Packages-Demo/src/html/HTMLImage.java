package html;

public class HTMLImage {

}
