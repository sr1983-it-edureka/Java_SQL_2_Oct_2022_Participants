package webbrowser;

public class BookmarkManager {

}
