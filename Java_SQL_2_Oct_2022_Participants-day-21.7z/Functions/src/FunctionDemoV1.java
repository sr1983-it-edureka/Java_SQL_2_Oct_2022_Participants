
public class FunctionDemoV1 {

	public static void main(String[] args) {
		
	
		// Open Browser - Navigate to Facebook
		
		System.out.println("Opening Chrome Browser");
		System.out.println("Navigated to facebook.com");
		System.out.println("Navigation Done...");
	
		// Print a document
		System.out.println("Sending a document to the printer...");
		System.out.println("Printer printing the first 10 pages..");
		System.out.println("Printer done its job");
		
		// Download a software
		System.out.println("Attempting to download the latest version "
				+ "of Google Chrome - 52.0");
		System.out.println("Software downloading is done...");
	}
}
