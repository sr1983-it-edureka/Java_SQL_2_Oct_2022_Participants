package classes;
import interfaces.Playable;

public class Footballer implements Playable{

	@Override
	public void play() {
		
		System.out.println("My aim the goal keeper and the goals");
	}

}
