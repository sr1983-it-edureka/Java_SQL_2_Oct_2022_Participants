package classes;

public interface Kite {

	void fly();
}
