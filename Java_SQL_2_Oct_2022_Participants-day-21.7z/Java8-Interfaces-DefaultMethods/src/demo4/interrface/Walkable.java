package demo4.interrface;

public interface Walkable {

	void walk();
}
