package demo4.interrface;

public interface Swimmable {

	void swim();
	
}
