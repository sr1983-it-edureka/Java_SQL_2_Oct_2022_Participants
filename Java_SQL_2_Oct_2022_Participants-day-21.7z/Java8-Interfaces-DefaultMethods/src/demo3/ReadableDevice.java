package demo3;

public interface ReadableDevice {

	String readData();
}
