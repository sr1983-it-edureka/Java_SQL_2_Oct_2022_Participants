package demo3;

public interface PenDrive 
	extends ReadableDevice, 
		WritableDevice, PlugabbleDevice{

}
