package defaultt.interfaces.demo3;

public class LaptopImpl implements Laptop{

	@Override
	public void build() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void changeOnwership() {
		
		System.out.println("Surrender your laptop to the admin");
		System.out.println("The inventoryy will be updated with the new owner");		
	}

}
