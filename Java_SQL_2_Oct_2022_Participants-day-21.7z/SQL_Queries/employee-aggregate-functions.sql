select * from employee;
select count(*) from employee;

select sum(sal) from employee;
select count(sal) from employee;

select avg(sal) from employee;

select min(sal) from employee;
select min(job) from employee;

select max(sal) from employee;
select max(job) from employee;



