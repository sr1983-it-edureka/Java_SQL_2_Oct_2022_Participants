create table player3 as
	select * from player;
    
select * from player3;
