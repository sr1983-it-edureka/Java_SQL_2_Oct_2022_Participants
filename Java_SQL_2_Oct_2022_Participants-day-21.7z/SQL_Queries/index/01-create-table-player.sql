create table player (
	playerid integer not null primary key,
    first_name varchar(20),
    last_name varchar(20),
    country varchar(20),
    age 
);