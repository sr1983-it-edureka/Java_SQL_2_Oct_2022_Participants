show indexes from player;
