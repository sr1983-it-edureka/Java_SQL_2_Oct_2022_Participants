
select * from employee;

select count(*) from employee;

select count(sal) from employee;

