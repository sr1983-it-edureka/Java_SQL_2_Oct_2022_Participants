package unary;

public class UnaryOperatorsDemo {

	public static void main(String[] args) {
		
		int a = 10;
		System.out.println(a);
		
		a++;
		// a = a + 1
		
		System.out.println(a);
		
		a--;
		a--;
		a--;
		a--;
		
		System.out.println(a);

		a+=10;
		// a = a + 10
		System.out.println(a);

		a-=20;
		System.out.println(a);
	}
}
