package binary;

public class ArithmeticOperatorsDemo {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		int c = a + b;
		System.out.println(c);
		
		
		
		// a, b -> Operands
		// - -> Operator
		int d = a - b;
		System.out.println(d);
		
		float salaryOfAnEmployee = 250000.50F;
		
		float bonusPercentage = 10.25F;
		
		float result1 = 
		(salaryOfAnEmployee * bonusPercentage) / 100;
		
		float
		revisedSalary = salaryOfAnEmployee + result1;
		
		System.out.println(revisedSalary);
		
		int x = 24;
		int y = 6;
		
		int z = x/y;
		System.out.println(z);
		
		int z1 = x % y;
		System.out.println(z1);
		
//		int i = 3;
	}
}
