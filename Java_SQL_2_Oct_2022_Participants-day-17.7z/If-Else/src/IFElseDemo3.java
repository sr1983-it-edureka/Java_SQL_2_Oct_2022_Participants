
public class IFElseDemo3 {

	public static void main(String[] args) {
		
//		int a = 10;
		
		// 1 - 7
		// 1 - Monday, 2 - Tuesday ... 7-Sunday
		
		int dayOfWeek = 3;
		
		if (dayOfWeek >=1 && dayOfWeek <=5) {
			System.out.println("Weekday !....");
		}else {
			System.out.println("Weekend ....");
		}
		
	}
	
}
