package com.edureka.javafsd2.java8.features;

@FunctionalInterface
public interface MonitorTweet {

	boolean monitor(String tweet);
	
}

/*
function monitor(String tweet) {
	
}*/