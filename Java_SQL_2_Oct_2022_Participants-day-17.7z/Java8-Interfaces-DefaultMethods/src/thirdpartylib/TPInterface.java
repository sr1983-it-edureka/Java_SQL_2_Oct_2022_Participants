package thirdpartylib;

public interface TPInterface {

	default void appointAssistant() {
		
	}
}
