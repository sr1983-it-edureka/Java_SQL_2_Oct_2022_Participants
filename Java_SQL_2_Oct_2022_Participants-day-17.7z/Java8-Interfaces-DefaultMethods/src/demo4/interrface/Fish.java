package demo4.interrface;

public interface Fish extends Swimmable{

}
