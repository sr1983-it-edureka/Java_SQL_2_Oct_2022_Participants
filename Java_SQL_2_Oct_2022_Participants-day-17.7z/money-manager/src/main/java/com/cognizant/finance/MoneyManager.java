package com.cognizant.finance;

import com.cognizant.calculator.Calculator;
import com.cognizant.core.utils.CollectionsUtils;
import com.cognizant.core.utils.StringUtils;

public class MoneyManager {

	public void manage() {
		
		CollectionsUtils collectionUtils;
		StringUtils stringUtils;
		
		Calculator calculator = new Calculator();
		calculator.add(10 , 10);
		 
	}
}
