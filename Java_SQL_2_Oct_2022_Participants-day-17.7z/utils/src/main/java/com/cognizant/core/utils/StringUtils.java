package com.cognizant.core.utils;

public class StringUtils {

}
