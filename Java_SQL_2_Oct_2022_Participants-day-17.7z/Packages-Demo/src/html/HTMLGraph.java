package html;

public class HTMLGraph {

}
