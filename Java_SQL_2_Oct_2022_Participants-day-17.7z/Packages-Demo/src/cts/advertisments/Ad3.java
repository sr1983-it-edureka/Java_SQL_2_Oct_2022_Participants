package cts.advertisments;

public class Ad3 {

}
