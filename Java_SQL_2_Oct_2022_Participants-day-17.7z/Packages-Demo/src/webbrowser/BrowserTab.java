package webbrowser;

public class BrowserTab {

}
