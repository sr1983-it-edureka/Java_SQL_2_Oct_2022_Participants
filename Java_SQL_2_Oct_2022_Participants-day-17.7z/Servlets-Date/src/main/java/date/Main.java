package date;

import java.util.Locale;

public class Main {

	public static void main(String[] args) {
		
		for (String country : Locale.getISOCountries()) {
			
//			Locale.get
			
//			System.out.println(country);
		}
	}
}
