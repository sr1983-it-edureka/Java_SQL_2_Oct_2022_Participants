package arraysum2;

public interface ArrayTotalCounter {

	int calculate(int []array);	
}
