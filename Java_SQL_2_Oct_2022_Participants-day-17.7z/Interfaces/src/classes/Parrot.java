package classes;
import interfaces.Singable;

public class Parrot implements Singable{

	@Override
	public void sing() {
		// TODO Auto-generated method stub
		
	}

}
