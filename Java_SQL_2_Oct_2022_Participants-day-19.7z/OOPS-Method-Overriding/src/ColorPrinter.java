import printer.Printer;

public class ColorPrinter extends Printer{

	public void print() {
		
		System.out.println(a);
		System.out.println("Printing some colored documents "
				+ "- with all the 7 possible colors...");
	}
}
