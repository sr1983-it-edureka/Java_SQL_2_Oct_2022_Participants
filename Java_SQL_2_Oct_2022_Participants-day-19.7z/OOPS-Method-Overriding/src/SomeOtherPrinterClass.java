import printer.Printer;

public class SomeOtherPrinterClass {

	void print() {
	
			Printer printer = new Printer();
//			printer.a
//			printer.myProtectedFunction();
	}
	
	public static void main(String[] args) {
		
	}
}
