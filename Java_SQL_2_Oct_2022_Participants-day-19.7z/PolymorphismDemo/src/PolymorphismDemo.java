
public class PolymorphismDemo {

	public static void main(String[] args) {
		
		// Element / Multiple Forms / Context -> Form to be expressed
		// 
		int c = 10 + 20;
		float z = 10.12F + 20.78F;
		String s1 = "Hello" + " everyone";
		
		// 
	}
}
