package interfaces.extension;

public class Windows10OS implements WindowsOS{

	@Override
	public void installedOnMachine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void uninstalledFromMachine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createMicrosoftAccount() {
		// TODO Auto-generated method stub
		
	}

}
