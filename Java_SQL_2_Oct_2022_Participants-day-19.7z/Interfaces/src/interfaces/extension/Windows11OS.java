package interfaces.extension;

public class Windows11OS implements WindowsOS{

	@Override
	public void installedOnMachine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void uninstalledFromMachine() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void createMicrosoftAccount() {
		// TODO Auto-generated method stub
		
	}

}
