package interfaces;

public interface Flyable {
	
	void fly();
}
