package classes;
import interfaces.Runnable;

public class Dog implements Runnable{

	public void run() {
		
		System.out.println("I feel like running, so I am running...");
		
	}

}
