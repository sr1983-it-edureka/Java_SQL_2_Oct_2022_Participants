/**
 * 
 */
/**
 * @author labuser
 *
 */
module JavaProject2 {
}