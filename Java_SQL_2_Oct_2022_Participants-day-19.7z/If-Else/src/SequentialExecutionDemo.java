
public class SequentialExecutionDemo {

	public static void main(String[] args) {
		
		int a = 10;
		System.out.println(a);
		
		int b;
		b = 20;
		System.out.println(b);
		
		int c = 30;
		c = 40;
		System.out.println(c);
	}
}
