
public class ToStringDemo {

	public static void main(String[] args) {
		
		int a = 10;
		System.out.println(a);
		
		float b = 1.23F;
		System.out.println(b);
		
		Planet earth = new Planet("Earth", true);
		System.out.println(earth);
		
	}
}
