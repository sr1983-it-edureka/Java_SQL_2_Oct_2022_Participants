
public class OperationsDemo {

	public static void main(String[] args) {
		
		// 250ns
		// int c = a + b;
			
		// 1234 ns
		// I/O (time consumming)
		// print("Hello")
		
		// I/O (time consuming)
		// Limit the interactions
		// get_input_from_user
		
		// calling_function
		
		
	}
}
