package datatypes.integer;

public class IntegerDataTypeDemo {

	public static void main(String[] args) {
		
		// 4 Bytes / 32 bits
	}
}
