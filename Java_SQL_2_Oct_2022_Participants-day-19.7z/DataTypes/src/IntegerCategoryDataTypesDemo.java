
public class IntegerCategoryDataTypesDemo {

	public static void main(String[] args) {
		
		// Integer category
		// byte, short, int, long
		
		int age = 100;
		System.out.println(age);
		
	}
}
