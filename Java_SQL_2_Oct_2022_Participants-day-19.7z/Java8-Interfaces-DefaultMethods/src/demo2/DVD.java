package demo2;

public interface DVD {

	String readData();
	
	void writeData(String data);
	
	void plugin();
}
