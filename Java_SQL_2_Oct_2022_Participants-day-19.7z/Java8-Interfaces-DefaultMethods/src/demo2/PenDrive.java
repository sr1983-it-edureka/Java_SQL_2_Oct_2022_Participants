package demo2;

public interface PenDrive {

	String readData();
	
	void writeData(String data);
	
	void plugin();
}
