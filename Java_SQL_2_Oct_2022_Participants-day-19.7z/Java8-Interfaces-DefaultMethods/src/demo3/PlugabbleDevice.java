package demo3;

public interface PlugabbleDevice {

	void plugin();
}
