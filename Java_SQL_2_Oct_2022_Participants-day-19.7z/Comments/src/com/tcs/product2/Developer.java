package com.tcs.product2;

/**
 * 
 * Inherits all the capabilities of engineer.
 * Also adds customization related to developemental activities such as
 * coding, unit-testing, participation in meetings, etc..
 * @author labuser
 *
 */
public class Developer extends Engineer{

}
