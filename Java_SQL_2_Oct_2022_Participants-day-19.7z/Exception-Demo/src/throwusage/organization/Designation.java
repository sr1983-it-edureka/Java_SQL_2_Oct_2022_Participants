package throwusage.organization;

public enum Designation {

	JUNIOR_PROGRAMMER,
	
	SENIOR_PROGRAMMER,
	
	TEAM_LEAD,
	
	TEAM_MANAGER
}
