
public class ActionFilePrintItselfDemo {

	class File {
		
		void print(Printer printer) {
			
		}
	}
	
	class Printer {}
	
	public static void main(String[] args) {
		
		/*
		 * Action
		 * 		// harry-potter file (pdf) wants to print itself by sending the 
		// contents to the printer printer-05


			Primary objects
				

		 */
		
		File harry_potter_file = null;
		Printer printer_01 = null;
		
		harry_potter_file.print(printer_01);
		
	}
}
