package webbrowser;

public class BrowserWindow {

}
