
// Child (Parent) Class / Sub (Super) Class / Derived (Base) Class
public class ApplicationProgrammer extends BaseProgrammer{

	
	ApplicationProgrammer(String lName, String lPrimaryProgrammingLanguage, 
			String[] lCertifications) {
		
		super(lName, lPrimaryProgrammingLanguage, lCertifications);
	}
	
}
