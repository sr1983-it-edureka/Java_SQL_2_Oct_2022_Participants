select * from employee;

select * from employee ORDER BY EMPNO ASC;
select * from employee ORDER BY EMPNO DESC;

select * from employee ORDER BY JOB DESC;


