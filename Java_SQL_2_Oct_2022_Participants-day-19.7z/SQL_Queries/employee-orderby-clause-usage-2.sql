select * from employee;

select * from employee ORDER by deptno DESC, SAL ASC;


select * from employee ORDER by deptno DESC, SAL ASC, MGR ASC;


