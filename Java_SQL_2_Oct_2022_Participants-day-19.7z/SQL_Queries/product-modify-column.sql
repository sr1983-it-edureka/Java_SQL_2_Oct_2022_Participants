alter table product modify column cost decimal(10, 2);
