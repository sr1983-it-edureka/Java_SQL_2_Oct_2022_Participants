show tables;

show full tables;
