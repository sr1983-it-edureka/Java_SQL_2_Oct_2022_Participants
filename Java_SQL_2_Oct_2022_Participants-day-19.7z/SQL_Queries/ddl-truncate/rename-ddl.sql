desc players_sa;

rename table player_sa TO players_south_africa;
desc players_south_africa;

alter table players_south_africa rename TO players_SA;
