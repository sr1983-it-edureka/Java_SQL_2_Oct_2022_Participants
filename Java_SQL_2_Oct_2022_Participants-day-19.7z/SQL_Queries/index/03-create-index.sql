create index player_country ON player (country);
