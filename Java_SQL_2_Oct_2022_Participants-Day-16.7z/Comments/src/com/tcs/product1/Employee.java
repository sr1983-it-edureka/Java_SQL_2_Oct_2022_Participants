package com.tcs.product1;

public class Employee {

}
