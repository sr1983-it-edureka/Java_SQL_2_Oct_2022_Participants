
public class WhileLoopDemo {

	public static void main(String[] args) {
		
		// Printing 'Exercise Affirmation' for 10 times
		// Action - Printing 'Affirmation'
		// Condition - 10 Times
		
		int counter = 10;
		while (counter <= 4) {

			System.out.println("I will do exercise regularly...");
//			counter = counter + 1;
			counter ++;
		}
		
	}
}
