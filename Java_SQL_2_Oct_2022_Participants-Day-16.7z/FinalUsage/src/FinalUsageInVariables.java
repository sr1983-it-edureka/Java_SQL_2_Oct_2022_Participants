
public class FinalUsageInVariables {

	public static void main(String[] args) {
		
		int age = 25;
		System.out.println("Age is " + age);
		
		age = 30;
		
		final double PI = 3.14;
		System.out.println("PI is " + PI);
		
//		PI = 4.14;
	}
	
}
