package classes;
import interfaces.Flyable;

public class Eagle implements Flyable{

	public void fly() {

		System.out.println("I can go upto longer distances");
		// TODO Auto-generated method stub
		
	}

}
