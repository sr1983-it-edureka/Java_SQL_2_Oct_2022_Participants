
public class ArraysDeclarationDemo {

	public static void main(String[] args) {
		
		int[] evenNumbers = {2, 4, 6, 8, 10};
		int oddNumbers[] = {1, 3, 5, 7, 9};
		
		int[] primeNumbers = new int[3];
		
		primeNumbers[0] = 3;
		primeNumbers[1] = 7;
		primeNumbers[2] = 13;
		
		int[] evenNumbers2 = new int[] {2, 4, 6, 8, 10};
	}
}
