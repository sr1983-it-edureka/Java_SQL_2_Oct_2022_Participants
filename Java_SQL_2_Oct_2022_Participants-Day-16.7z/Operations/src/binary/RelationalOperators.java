package binary;

public class RelationalOperators {

	public static void main(String[] args) {
		
		int x  = 15;
		int y = 25;
		
		int z = x + y;
		boolean z1 = x > y;
//		System.out.println(z1);
//		
//		System.out.println(x > y);
//		
//		System.out.println(15 > 25);
		
		System.out.println(43 > 56);
		System.out.println(65 != 65);
		System.out.println(54 < 876);
		System.out.println(23 <= 24);
		System.out.println(98 >= 67);
		System.out.println(10 != 10);
		System.out.println(867 == 867);
		
	}
}
