package defaultt.interfaces.demo3;

public interface Buildable {

	void build();
}
