package defaultt.interfaces.demo3;

public interface Laptop extends Buildable,
	ChangeOwnership{

}
