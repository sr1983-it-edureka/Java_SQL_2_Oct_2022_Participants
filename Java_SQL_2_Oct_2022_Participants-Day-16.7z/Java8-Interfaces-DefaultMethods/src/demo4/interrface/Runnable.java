package demo4.interrface;

public interface Runnable {

	void run();
}
