package demo3;

public interface DVD extends 
	ReadableDevice, 
		WritableDevice, 
			PlugabbleDevice{

}
