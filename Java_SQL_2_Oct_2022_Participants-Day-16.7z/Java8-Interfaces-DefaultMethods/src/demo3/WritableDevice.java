package demo3;

public interface WritableDevice {

	void writeData(String data);
	
}
