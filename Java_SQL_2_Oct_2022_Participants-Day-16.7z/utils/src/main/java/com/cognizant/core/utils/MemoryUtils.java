package com.cognizant.core.utils;

public class MemoryUtils {

}
