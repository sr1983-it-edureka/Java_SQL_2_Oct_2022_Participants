
public class TypeConversionDemo2 {

	public static void main(String[] args) {
		
		// float, double
		System.out.println(1.23);
		// Deffault is DOUBLE (not Float)
		
//		float f1 = 1.23;
		float f2 = 1.23F;
		float f3 = (float)1.23;
		
		double d1 = 1.23;
		double d2 = 1.23D;
	}
}
