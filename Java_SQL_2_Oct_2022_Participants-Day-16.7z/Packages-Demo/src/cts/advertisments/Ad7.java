package cts.advertisments;

public class Ad7 {

}
