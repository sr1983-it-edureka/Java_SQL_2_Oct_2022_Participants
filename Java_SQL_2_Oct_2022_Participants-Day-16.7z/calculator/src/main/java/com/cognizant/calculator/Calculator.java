package com.cognizant.calculator;

import com.cognizant.core.utils.CollectionsUtils;
import com.cognizant.core.utils.StringUtils;

public class Calculator {

	public int add (int a, int b) {

		CollectionsUtils collectionUtils;
		
		StringUtils stringUtils;
		return a+b;
	}

	public int sub(int a, int b) {
		return a-b;
	}
}
