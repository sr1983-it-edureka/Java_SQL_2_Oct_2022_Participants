package datatypes.integer;

public class LongDataType {

	public static void main(String[] args) {
		
		// 8 bytes - 64 bits
		
		long populationCount = 139243943473843L;
	}
}
