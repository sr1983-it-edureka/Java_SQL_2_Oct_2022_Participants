
public class TODOProject {

	public static void main(String[] args) {
		
		// NOT DONE
		// Comments (3) Java
		// Maven - default is 1.7 -> change it
		// Usage of "static" method
		// protected usage
		// Usage of Object class and its relation to toString()
		// Usage basic-collection 
		// Method Overriding -> Then come back toString()
		// IntelliJ - Project Dependencies Addition Possible - ?
		// "hash" 
		// Wrapper
		// Eclipse - Project Dependencies - Not working
		// Map traversal through Map.Entry
		// TODO - To go through chats
		// @Override discuss
		// Break / Continue statement
		// Multi Dimension Array
		// Plymorphism (Static & Dynamic)
		// StringBuffer (Thread)
		// Abstract usage
		// Final
		// Sort -> Custom Objects [Sorting Algorthm]
		// Checked and Uncheck Exception
		// Multiple catch and Nested try-catch
		// Thread
		// Collection - TreeSet, TreeMap, Vector, Hashtable, Properties
		// Enumeration, ListIterator
		// Queue / P Queue
		// Inner classes
		
		// DONE
		
		// Usage of "this" 
		// Usage of public/private
		// Usage of "toString()"
		// String.format

		// OPTIONAL
			// File - copy
		
	}
}
