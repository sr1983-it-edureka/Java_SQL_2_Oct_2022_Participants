package interfaces.extension;

public interface MacOS extends OS{

	void createAppleAccount();
}
