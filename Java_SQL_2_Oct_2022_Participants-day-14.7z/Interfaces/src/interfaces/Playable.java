package interfaces;

public interface Playable {

	void play();
}
