package cts.advertisments;

public class Ad1 {

}
