package network;

public class NetworkUtils {

	int readDataFromPort() {
		System.out.println("reading information from port");
		return 123;
	}
	
	void writeDataToPort() {
		System.out.println("Writing data to port...");
	}
}
