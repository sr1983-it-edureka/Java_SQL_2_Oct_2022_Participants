
public class DoWhileLoop {

	public static void main(String[] args) {
				
		int counter = 10;
		do {
			System.out.println("I will do exercise regularly...");
			counter = counter + 1;
		}while (counter <=4);
	}
}
