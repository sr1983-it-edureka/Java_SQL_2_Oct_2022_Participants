
public class FinalUsageWithClasses {

}


final class Algorithm{
	
	public void algoritmicMethod() {
		
		System.out.println("Secret steps are there for the algorithm logic");
	}
}
//
//class ApacheAlgorithm extends Algorithm{
//	
//}

