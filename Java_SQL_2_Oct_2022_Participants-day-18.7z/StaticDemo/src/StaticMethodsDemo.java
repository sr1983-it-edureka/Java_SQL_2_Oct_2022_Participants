
public class StaticMethodsDemo {

	public static void main(String[] args) {
		
	}
}
