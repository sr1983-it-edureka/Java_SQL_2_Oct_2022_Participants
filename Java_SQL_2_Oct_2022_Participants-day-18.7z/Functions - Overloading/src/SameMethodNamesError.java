
public class SameMethodNamesError {

	public static void main(String[] args) {
		
	}
	
//	void doSomething() {
//		
//	}
//	
//	void doSomething() {
//		
//	}
	
	
	void doSomething(int a) {
		
	}
	
	void doSomething() {
		
	}	
}
