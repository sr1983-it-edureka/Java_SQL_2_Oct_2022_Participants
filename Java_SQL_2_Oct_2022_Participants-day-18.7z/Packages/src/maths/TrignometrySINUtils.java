package maths;

public class TrignometrySINUtils {

	double sin(int value) {
		return 12.3;
	}
}
