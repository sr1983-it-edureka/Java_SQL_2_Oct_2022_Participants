package maths;

public class TrignometryCOSUtils {

	double cos(int degree) {
		return 4.3;
	}
}
