package interfaces.demo;

public interface Browser {

	void launch();
	
	void close();
	
	void openTab();
	
	void closeTab();
}
