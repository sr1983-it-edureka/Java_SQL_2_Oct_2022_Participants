package com.edureka.javafsd2.java8.features;

@FunctionalInterface
public interface Addition {

	int add(int a, int b);
}
