alter table product add column cost integer;
