package defaultt.interfaces.demo3;

public interface House extends Buildable,
	ChangeOwnership{

}
