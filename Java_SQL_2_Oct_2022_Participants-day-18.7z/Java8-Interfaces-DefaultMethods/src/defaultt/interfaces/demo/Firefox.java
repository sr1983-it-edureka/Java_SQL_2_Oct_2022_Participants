package defaultt.interfaces.demo;

public class Firefox implements Browser{

	@Override
	public void openTab() {
		System.out.println("Opening firefox tab");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void closeTab() {
		
		System.out.println("Closing firefox tab");
		// TODO Auto-generated method stub
		
	}

}
