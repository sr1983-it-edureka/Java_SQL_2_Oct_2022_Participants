package demo3;

public interface Flyable {

	void fly();
}
