
public class GeneralInheritance {

	// Parent (Father / Mother)
	// Child (Daughter / Son)
	// Wealth (property, car) [Parent]
	
	// Child can inherit property from Parent
	// {Car} -> parent , {Car} -> child
	
	// Parent -> ParentClass
	// Child -> ChildClass
	// Wealth (Properties, Methods) [Parent]
	
	// A child-class can inherit [properties, methods] from parent-class
}
