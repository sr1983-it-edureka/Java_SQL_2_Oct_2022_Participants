
public class DataTypesDemo {

	public static void main(String[] args) {
		
		int noOfTransactions = 400;
		
		float interestRateForLoan = 7.89F;
		float interestrateforloan = 8434.5F;
		float interest_rate_for_loan = 4343.32F;
		
		int noOfParticipants = 25;
		
		char someCharacter = 'A';
		someCharacter = 'U';
		
		boolean tomorrowAHoliday = true;
		boolean dayAfterTomorrowAHoliday = false;
		
		int a = 10;
		int b = 20;
		int float1 = 30;
		int char1 = 43;
		
		int true1 = 50;
		int false1 = 60;
		
	}
}
